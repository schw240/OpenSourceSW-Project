package com.example.myapplication4;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.io.ByteArrayInputStream;

public class MainActivity extends AppCompatActivity {
    Button sendImage;
    ImageView imageview1;
    ImageView imageview2;
  //  private InputStream in = null;

    public void sendTextMsg(DataOutputStream out, String msg) throws IOException {
        byte[] bytes = msg.getBytes();
        long len = bytes.length;
        out.writeLong(len);
        out.write(bytes);
    }

    public void sendImgMsg(DataOutputStream out) throws IOException {

//        Log.i("sendImgMsg", "len: " + "1");
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
        //    System.out.println(bitmap);
//        Log.i("sendImgMsg", "len: " + "2");
        ByteArrayOutputStream bout = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 80, bout);
      //      System.out.println(bitmap.compress(Bitmap.CompressFormat.PNG, 80, bout));
        //写入字节的长度，再写入图片的字节
        long len = bout.size();
        //这里打印一下发送的长度
  //      Log.i("sendImgMsg", "len: " + len);
        out.write(bout.toByteArray());
    //        System.out.println(len);
  //          System.out.println(bout);
    }

    public void recvImgMsg(DataInputStream in) throws IOException {


    //    Byte buff[] = new byte[1024];

   //     Log.d("recvImgMsg", "len: " + "1");
    //    Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);

//        Log.d("recvImgMsg", "len: " + "2");
    //    ByteArrayOutputStream bout = new ByteArrayOutputStream();
    //    bitmap.compress(Bitmap.CompressFormat.PNG, 80, bout);
        //写入字节的长度，再写入图片的字节
        //这里打印一下发送的长度
     //   Log.i("recvImgMsg", "len: " + len);
     //   out.write(bout.toByteArray());

        Bitmap bm = BitmapFactory.decodeStream(in);

        int imagesize = 100000;
        byte bytes[]  = new byte[1024];
        in.read(bytes);

  //      byte[] byteArr = inputStreamToByteArray(in);
     //   int readByteCount = in.read(byteArr);
    //    String data = new String(byteArr, 0, readByteCount, "UTF-8");


//        Bitmap bm = BitmapFactory.decodeByteArray(byteArr,0,byteArr.length);
//        imageview2.setImageBitmap(bm);

//        for(int i =0; i<byteArr.length; i++)
  //      {
  //          System.out.print(byteArr[i] +" ");
    //    }
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sendImage = (Button) findViewById(R.id.buttonsend);
        imageview1 = (ImageView) findViewById(R.id.image1);
        imageview2 = (ImageView) findViewById(R.id.image2);
        Handler mHandler = new Handler(Looper.getMainLooper());
        sendImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread() {
                    Socket socket;
             //       Socket socket2;
            //        Socket socket2;
                    String host = "172.25.244.6";
                    int post = 9000;
           //         int post2 = 9002;
              //      int post2 = 9888;


                    public void run() {
                        try {
                            socket = new Socket(host, post);
                            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
                //            socket1.connect("172.25.244.6",post1);
                              sendImgMsg(out);
     //                       recvImgMsg(in);
     //                       out.close();
                            out.close();
                            ///////////////////////////////여기서 스트림이 꺼지면서 소켓도 같이 꺼져가지고, 소켓 끊어졌다고 오류뜨는데 소켓 두 개 다른 포트에 연결하면 오류는 안뜨는데  이 줄 밑으로 실행이 안됨/////////////////////

                            socket = new Socket(host, post);
                            final InputStream in = new BufferedInputStream(socket.getInputStream());
                            in.mark(3);
                            int i = 0;
                            byte[] buf = new byte[1024];
                            while((i=in.read(buf))!=-1){
                                System.out.println(i);
                            }

                            in.close();

                            Handler mHandler = new Handler(Looper.getMainLooper());
                            mHandler.postDelayed(new Runnable() {


                                @Override

                                public void run() {
                                    //
                                    Bitmap bm = BitmapFactory.decodeStream(in);
                                    //image receiving
                                   //                        InputStream in = socket.getInputStream();
                                    imageview2.setImageBitmap(bm);



                                }

                            }, 1000);

//                            InputStream in = new DataInputStream(socket2.getInputStream());
 //                           System.out.println(socket2.isClosed());
  //                          recvImgMsg(in);
  //                          System.out.println(socket2.isClosed());
  //                          Bitmap resultBitmap = BitmapFactory.decodeStream(in);
  //                          retrun resultBitmap;
  //                          imageview2.setImageBitmap(Bitmap.createScaledBitmap(resultBitmap,213,415,false));
   //                         in.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }



                    }


                }.start();
            }
        });

    }
}
