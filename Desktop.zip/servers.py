from socket import *
import socket
import os
import time
import sys

src = "C:\\Users\\New_Commer_2\\servers\\"


def fileName():
    dte = time.localtime()
    Year = dte.tm_year
    Mon = dte.tm_mon
    Day = dte.tm_mday
    WDay = dte.tm_wday
    Hour = dte.tm_hour
    Min = dte.tm_min
    Sec = dte.tm_sec
    imgFileName = src + str(Year) + '_' + str(Mon) + '_' + str(Day) + '_' + str(Hour) + '_' + str(Min) + '_' + str(
        Sec) + '.jpg'
    return imgFileName


server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(("", 5000))
server_socket.listen(5)

print("TCPServer Waiting for client on port 5000")

while True:

    client_socket, address = server_socket.accept()

    print("I got a connection from ", address)

    data = None


    while True:
        img_data = client_socket.recv(1024)
        data = img_data
        if img_data:
            while img_data:
                print("recving Img...")
                img_data = client_socket.recv(1024)
                data += img_data
            else:
                break


    img_fileName = fileName()
    img_file = open(img_fileName, "wb")
    print("finish img recv")
    print(sys.getsizeof(data))
    img_file.write(data)
    img_file.close()
    print("Finish ")

client_socket.close()
print("SOCKET closed... END")


def send_img(filename):
    capture_file_name = "C://Users//New_commer_2//servers//" + str(filename) + ".jpg"
    file = open(capture_file_name, "rb")
    img_size = os.path.getsize(capture_file_name)
    img = file.read(img_size)
    file.close()
    client_socket.sendall(img)


server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(("", 5000))
server_socket.listen(1)

print("TCPServer Waiting for client on port 5000")

while True:
 
    client_socket, address = server_socket.accept()

    print("I got a connection from ", address)

    if client_socket.recv(1024) == b'hi':

        filename_list = [1, 2, 3, 4, 5, 6]  
        file_count = len(filename_list)
        client_socket.send(b'%d' % file_count)
        for i in filename_list:
            send_img(i)
            print(str(i) + "image finish!!!!")
            client_socket.send(b'finish') 
            time.sleep(5)  
        print('대기중............')
    else:
        client_socket.close()
        print('Socket closed')
        